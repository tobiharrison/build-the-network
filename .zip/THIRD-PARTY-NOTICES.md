# Third-party assets

Bundled production libraries:

- jQuery 3.7.1 — MIT; https://jquery.com/
- Bootstrap CSS 5.3.3 — MIT; https://getbootstrap.com/
- Globe.GL 2.32.0 — MIT; https://github.com/vasturiano/globe.gl
- Globe.GL's standalone distribution includes Three.js and its dependencies. Their notices are preserved in the bundle and `assets/vendor/LICENSES.txt`.
- DM Sans and Barlow Condensed from the @fontsource packages — SIL Open Font License; see license files in `assets/fonts/`.
- `earth-night.jpg` and `earth-topology.png` are the sample Earth textures distributed with the `three-globe` 2.45.6 npm package, https://github.com/vasturiano/three-globe. Its MIT license is included as `assets/images/THREE-GLOBE-LICENSE.txt`.

The simplified SVG map and brand mark were created for this project. SVG geography is a stylized visual backdrop without political boundaries; it is not survey cartography. LoveWorld Radio branding/text supplied through the brief remains subject to the department's authorization.

The application's production runtime does not require npm. The versions above refer to the bundled assets; review/update dependencies through a normal tested maintenance process.
