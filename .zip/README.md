# Build the Network — GitHub Pages demo

This folder is the static presentation version of the LoveWorld Radio network experience. Upload its **contents** to a GitHub repository. It needs no PHP, MySQL, npm installation or build command.

## Publish for free

1. Create a **public** GitHub repository, for example `build-the-network`.
2. Extract this ZIP. Open the `build-the-network-github` folder.
3. Upload everything **inside** that folder to the repository's root, keeping `assets/` and `data/` as folders. `index.html` must be directly visible in the repository root, not inside another folder. Commit the files to `main`.
4. Open your repository's **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select branch **main** and folder **/(root)**, then **Save**.
7. When publishing finishes, use the website URL shown on that Pages settings screen. It will usually follow `https://YOUR-USERNAME.github.io/build-the-network/`.

Do not upload the ZIP itself as the website; upload the extracted files. If the browser upload interface does not preserve a folder, drag the `assets` and `data` folders from File Explorer, or use Git/GitHub Desktop.

Official instructions: https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site

## Files you should see at the repository root

- `index.html` — the complete public experience.
- `privacy.html` — the static demo's privacy explanation.
- `assets/` — scripts, styling, textures, fonts and bundled libraries.
- `data/network.json` — public illustrative stations, scenarios, metrics and packages.
- `.nojekyll` — tells Pages to serve the static files directly.
- `README.md`, `THIRD-PARTY-NOTICES.md` and `.gitignore`.

## What works

- 3D globe, local Earth night/terrain textures and an interactive 2D fallback.
- All five station milestones: 1 / 10 / 50 / 100 / 1,000.
- Browser-local completed-activation tracking and invitation after three experiences.
- Continued exploration without partnership, station details/search, region filters, coverage and connection switches, rotation pause, optional activation sound and reduced motion.
- Scenario comparison, static share links and partnership package previews.
- Restart demo clears this browser's progress.

All example stations, station schedules, coverage groups and contribution amounts remain illustrative. Audience remains unavailable until supporting data is provided. The 1,000-station scenario uses aggregated markers for performance but retains complete network totals.

## What this demo does not do

There is no server-side admin login, database, central analytics, inquiry submission or payment processing. Personal details are not collected. Progress is stored locally in this browser, can be reset/edited by the browser, and is not authoritative. If browser storage is blocked, progress survives only while the page is open.

Use the separate PHP/MySQL project for production database features. Do not copy its configuration files, account information, uploads, SQL exports or inquiry records into this public repository.

## Optional official partnership link

Open `assets/js/demo-config.js` and set `officialPartnershipUrl` to the department's approved HTTPS platform. With the default empty value, the demo displays package previews and does not offer an active payment button.

The external platform must collect/confirm any real contribution. A demo package amount is not sent to that platform, no inquiry is created, and this website never claims payment completion. Do not put gateway keys or passwords in this public file.

`attemptLimit: 3` sets the automatic invitation threshold. Use `0` to disable it.

## Customize data and content

- Edit landing/reveal copy in `index.html`.
- Edit `data/network.json` for sample station data, packages and scenario settings.
- Each `networks` entry contains station IDs, routes and precomputed impact totals. Update the totals and methodology together when changing memberships; this static version does not recalculate server statistics.
- Global settings in the JSON include colors and whether sound is offered.
- All paths are relative and sharing uses the deployed page's actual URL, so a repository subfolder works without hardcoded domain edits.

## Preview locally

Use VS Code **Live Server** to open `index.html`, or run a local static HTTP server. Opening it by double-clicking a `file://` path may block the JSON fetch. No application server is required after deployment to GitHub Pages.

## Checks completed

JavaScript syntax and DOM regression checks passed for repository-path data loading, all five controls, single-count activation, third-experience invitation, continued exploration, the complete 1,000-station dataset, comparison, package previews without personal-data fields, static sharing, persistence and HTTPS-only partnership links. Tests confirmed that the demo makes no PHP/API POST requests.

Actual WebGL rendering and mobile layout still need checking in a real browser after publishing. If WebGL is unavailable, the 2D view remains usable.
